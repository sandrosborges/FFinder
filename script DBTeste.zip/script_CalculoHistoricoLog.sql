CREATE TABLE CalculoHistoricoLog(
    [ID] [int] IDENTITY(1,1) NOT NULL,
    [CoordinatexIN] [int] NOT NULL,
    [CoordinateyIN] [int] NOT NULL,    
    [IdFriend] [int] NOT NULL,        
    [FriendName] [varchar](150) NOT NULL,
    [FriendsDistance] [numeric] NOT NULL

 CONSTRAINT [PK_CalculoHistoricoLog] PRIMARY KEY CLUSTERED 
(
    id ASC
)
) ON [PRIMARY]
