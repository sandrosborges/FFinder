CREATE TABLE Friend(
    [ID] [int] IDENTITY(1,1) NOT NULL,
    [CoordinateX] [int] NOT NULL,
    [CoordinateY] [int] NOT NULL,    
    [name] [varchar](150) NOT NULL

 CONSTRAINT [PK_Friend] PRIMARY KEY CLUSTERED 
(
    id ASC
)
) ON [PRIMARY]
