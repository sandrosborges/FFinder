insert into Friend (CoordinateX, CoordinateY, name)
select 20,30,'Jhon Doe' union
select 80,10,'Mary' union
select 100,200,'George' union
select 50,310,'Lucas' union
select 90,70,'Francis' union
select 200,20,'Francisco' union
select 300,30,'Bart' union
select 120,155,'Homer' union
select 5,310,'Luke' union
select 400,45,'Darwin' union
select 350,80,'Neil' union
select 700,25,'Solomon' union
select 185,5,'Barry' union
select 35,30,'Bruce' union
select 45,95,'Oliver'



